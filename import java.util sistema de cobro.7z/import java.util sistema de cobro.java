import java.util.Scanner;

class Cliente {
    String nombre;
    String metodoPago;
    double montoAPagar;
    String numeroTarjeta;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public void seleccionarMetodoPago() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Seleccione el método de pago (efectivo/tarjeta): ");
        metodoPago = scanner.nextLine();

        if (metodoPago.equalsIgnoreCase("tarjeta")) {
            System.out.println("Ingrese el número de su tarjeta: ");
            numeroTarjeta = scanner.nextLine();
        }
    }

    public void ingresarMonto(double monto) {
        this.montoAPagar = monto;
    }

    public void mostrarInfoPago() {
        if (metodoPago.equalsIgnoreCase("tarjeta")) {
            System.out.println("Cliente: " + nombre + "\nMétodo de pago: Tarjeta\nNúmero de tarjeta: " + numeroTarjeta + "\nMonto a pagar: " + montoAPagar);
        } else {
            System.out.println("Cliente: " + nombre + "\nMétodo de pago: Efectivo\nMonto a pagar: " + montoAPagar);
        }
    }
}

class Empleado {
    String nombre;

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public void cobrar(Cliente cliente) {
        System.out.println("Empleado " + nombre + " está procesando el cobro...");
        cliente.mostrarInfoPago();
        System.out.println("Cobro realizado con éxito.");
    }
}

public class Minimarket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Crear cliente
        System.out.println("Ingrese el nombre del cliente: ");
        String nombreCliente = scanner.nextLine();
        Cliente cliente = new Cliente(nombreCliente);

        // Ingresar el monto a pagar
        System.out.println("Ingrese el monto total de la compra: ");
        double montoCompra = scanner.nextDouble();
        cliente.ingresarMonto(montoCompra);

        // Seleccionar método de pago
        cliente.seleccionarMetodoPago();

        // Crear empleado y realizar el cobro
        Empleado empleado = new Empleado("Carlos");
        empleado.cobrar(cliente);
    }
}
